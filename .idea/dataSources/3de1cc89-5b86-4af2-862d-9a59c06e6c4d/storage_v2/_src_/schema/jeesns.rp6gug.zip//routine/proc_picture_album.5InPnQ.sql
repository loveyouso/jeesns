CREATE PROCEDURE proc_picture_album()
  BEGIN
    DECLARE Done INT DEFAULT 0;
    DECLARE memberid INT;
    DECLARE rs CURSOR FOR SELECT id FROM tbl_member;
    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET Done = 1;
    OPEN rs;
    FETCH NEXT FROM rs INTO memberid;
    REPEAT
      IF NOT Done THEN
        insert into tbl_picture_album(id,create_time,update_time,member_id,name,juri,type,cover)
        values(memberid,now(),now(),memberid,"微博配图",0,2,"/res/common/images/empty_album.png");
        update tbl_picture set album_id=memberid where member_id=memberid;
      END IF;
      FETCH NEXT FROM rs INTO memberid;
    UNTIL Done END REPEAT;
    CLOSE rs;
  end;

